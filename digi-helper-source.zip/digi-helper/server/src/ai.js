// OpenAI integration. The API key stays on the server; the browser never sees it.
import OpenAI, { toFile } from 'openai';

const key = process.env.OPENAI_API_KEY;
const client = key ? new OpenAI({ apiKey: key }) : null;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const VISION_MODEL = process.env.OPENAI_VISION_MODEL || MODEL;

export const aiEnabled = !!client;

const LANG_NAME = { en: 'English', ar: 'Arabic (Modern Standard Arabic, friendly school register, Western digits 0-9)', fr: 'French (use « tu » with the student)' };
const langLine = (lang) => `\nAlways reply in ${LANG_NAME[lang] || LANG_NAME.en}. Keep maths expressions, code and English sentences being studied exactly as written.`;

const TUTOR_SYSTEM = `You are Digi Helper, a patient tutor inside a personalized learning platform for school students (ages 11-18).
Your job is to TEACH, not to hand out answers.
- When a student asks for an answer, guide them with one question or hint at a time. Only give a full worked answer after they have tried at least twice, and then explain every step.
- Explain concepts simply, with a concrete example or visual analogy (number lines, balance scales, pizza slices).
- When the student is wrong, name the likely misconception kindly and specifically.
- Adapt to the learning data you are given (weakest concepts, recent mistakes, preferred learning mode). If they struggled with a topic before, say so gently and try a different approach, e.g. "You have struggled with this before. Let's approach it visually this time."
- Offer a short practice question when useful. Encourage effort, never shame.
- Keep replies under 140 words. Use plain text; simple line breaks are fine. Use the minus sign − for negatives.
- Stay on schoolwork. If asked about anything unsafe or unrelated, steer back to learning politely.`;

function profileLine(student) {
  if (!student) return 'No learning data available (guest).';
  const w = (student.weakest || []).map((x) => `${x.concept} ${x.mastery}%`).join(', ');
  const m = (student.recentMistakes || []).map((x) => `${x.question} answered ${x.answer} (${x.pattern})`).join('; ');
  return `Student: ${student.name || 'student'}, ${student.grade || ''}. Prefers ${student.preference || 'any'} learning. Weakest: ${w || 'unknown'}. Recent mistakes: ${m || 'none'}.`;
}

export async function tutorReply({ messages, student, context, lang }) {
  const sys = `${TUTOR_SYSTEM}${langLine(lang)}\n\nLearning data: ${profileLine(student)}${context?.concept ? `\nCurrent topic: ${context.concept}.` : ''}${context?.question ? `\nThe student is working on: ${context.question}. Do not reveal its answer directly.` : ''}`;
  const r = await client.chat.completions.create({ model: MODEL, temperature: 0.5, max_tokens: 400, messages: [{ role: 'system', content: sys }, ...messages] });
  return r.choices[0]?.message?.content?.trim() || 'Let’s try that again — can you rephrase your question?';
}

export async function explainMistake({ prompt, question, studentAnswer, correctAnswer, pattern, lang }) {
  const r = await client.chat.completions.create({
    model: MODEL, temperature: 0.4, max_tokens: 250,
    messages: [{ role: 'system', content: `${TUTOR_SYSTEM}\nExplain a single mistake in 3 short sentences: what likely happened, why it is wrong, and a tip to avoid it. No greeting.${langLine(lang)}` },
      { role: 'user', content: `${prompt} ${question}\nStudent answered: ${studentAnswer}\nCorrect answer: ${correctAnswer}\nDetected pattern: ${pattern || 'unknown'}` }],
  });
  return r.choices[0]?.message?.content?.trim() || '';
}

export async function recommend({ diagnosis, preference, lang }) {
  const r = await client.chat.completions.create({
    model: MODEL, temperature: 0.5, max_tokens: 220,
    messages: [{ role: 'system', content: 'You write a short, encouraging, specific study recommendation (max 70 words) for a school student based on a learning diagnosis. Mention which concept to fix first and one concrete activity. Plain text.' + langLine(lang) },
      { role: 'user', content: JSON.stringify({ diagnosis, preferredMode: preference }) }],
  });
  return r.choices[0]?.message?.content?.trim() || '';
}

/** Read handwritten work: returns { steps: string[], note } — the server then checks the maths deterministically. */
export async function transcribeWork(buffer, mime) {
  const r = await client.chat.completions.create({
    model: VISION_MODEL, temperature: 0, max_tokens: 500,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: 'You transcribe a student\'s handwritten algebra working. Return JSON: {"steps": ["one equation per line exactly as written, using x as the variable, ASCII + - * / = and parentheses"], "note": "one short sentence about legibility or anything you were unsure of"}. Copy what the student wrote, including mistakes. Do not correct or solve anything. If there are no equations, return {"steps": [], "note": "..."}.' },
      { role: 'user', content: [{ type: 'text', text: 'Transcribe each line of working.' }, { type: 'image_url', image_url: { url: `data:${mime};base64,${buffer.toString('base64')}`, detail: 'high' } }] },
    ],
  });
  let parsed;
  try { parsed = JSON.parse(r.choices[0]?.message?.content || '{}'); } catch { parsed = {}; }
  const steps = Array.isArray(parsed.steps) ? parsed.steps.filter((s) => typeof s === 'string').map((s) => s.slice(0, 120)).slice(0, 15) : [];
  return { steps, note: typeof parsed.note === 'string' ? parsed.note.slice(0, 200) : '' };
}

// ---------- voice ----------
const TTS_MODEL = process.env.OPENAI_TTS_MODEL || 'gpt-4o-mini-tts';
const TTS_VOICE = process.env.OPENAI_TTS_VOICE || 'nova';
const STT_MODEL = process.env.OPENAI_STT_MODEL || 'whisper-1';

/** Text → spoken MP3 (Buffer). A warm, encouraging tutor voice. */
export async function speakText(text, lang) {
  const r = await client.audio.speech.create({
    model: TTS_MODEL, voice: TTS_VOICE, input: text, response_format: 'mp3',
    ...(TTS_MODEL.startsWith('gpt-') ? { instructions: `Speak as a warm, patient, encouraging tutor for school students${lang === 'ar' ? ', in Modern Standard Arabic' : lang === 'fr' ? ', in French' : ''}. Clear and friendly, not too fast.` } : {}),
  });
  return Buffer.from(await r.arrayBuffer());
}

/** Speech (webm/ogg/mp4/wav) → text. The audio is processed in memory and never stored. */
export async function transcribeSpeech(buffer, mime, lang) {
  const ext = { 'audio/webm': 'webm', 'audio/ogg': 'ogg', 'audio/mp4': 'mp4', 'audio/mpeg': 'mp3', 'audio/wav': 'wav', 'audio/x-wav': 'wav' }[mime] || 'webm';
  const r = await client.audio.transcriptions.create({ model: STT_MODEL, file: await toFile(buffer, `speech.${ext}`, { type: mime }), language: lang });
  return (r.text || '').trim();
}
