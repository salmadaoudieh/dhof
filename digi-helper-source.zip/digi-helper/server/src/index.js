import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import { randomUUID } from 'node:crypto';
import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { users, progress, assignments } from './db.js';
import { hashPassword, verifyPassword, signToken, requireAuth } from './auth.js';
import { aiEnabled, tutorReply, explainMistake, recommend, transcribeWork, speakText, transcribeSpeech } from './ai.js';
import { analyzeSteps } from '../../shared/linear.js';

const app = express();
const PORT = Number(process.env.PORT || 8787);
const here = dirname(fileURLToPath(import.meta.url));

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'blob:'],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
      mediaSrc: ["'self'", 'blob:'],
    },
  },
}));
app.use(express.json({ limit: '300kb' }));

// ---------- helpers ----------
const clean = (v, max = 200) => String(v ?? '').replace(/[\u0000-\u0009\u000B-\u001F\u007F<>]/g, '').trim().slice(0, max);
const USERNAME = /^[a-zA-Z0-9_.-]{3,24}$/;
const ROLES = new Set(['student', 'teacher']);
const MODES = new Set(['visual', 'interactive', 'practice', 'explain']);
const langOf = (v) => (['en', 'ar', 'fr'].includes(v) ? v : 'en');
const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Wait a few minutes and try again.' } });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Digi Helper needs a short break. Try again in a minute.' } });
const needAI = (req, res, next) => (aiEnabled ? next() : res.status(503).json({ error: 'AI features are not configured on this server.' }));

// ---------- health ----------
app.get('/api/health', (req, res) => res.json({ ok: true, ai: aiEnabled }));

// ---------- auth ----------
function publicUser(row) { const p = JSON.parse(row.profile); return { id: row.id, role: row.role, username: row.username, ...p }; }

app.post('/api/auth/signup', authLimiter, (req, res) => {
  const { role, username, password } = req.body || {};
  if (!ROLES.has(role)) return res.status(400).json({ error: 'Choose student or teacher.' });
  if (!USERNAME.test(username || '')) return res.status(400).json({ error: 'Usernames are 3–24 letters, numbers, dots, dashes or underscores.' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 200) return res.status(400).json({ error: 'Use a password with at least 8 characters.' });
  const name = clean(req.body.name, 40);
  if (name.length < 2) return res.status(400).json({ error: 'Tell us what to call you.' });
  // Only the minimum profile is stored — no email, birthday or contact details.
  const profile = role === 'student'
    ? { name, grade: clean(req.body.grade, 20), subjects: (Array.isArray(req.body.subjects) ? req.body.subjects : []).map((s) => clean(s, 30)).slice(0, 8), preference: MODES.has(req.body.preference) ? req.body.preference : 'practice', avatar: clean(req.body.avatar, 8), lang: langOf(req.body.lang) }
    : { name, school: clean(req.body.school, 60) };
  const uname = username.toLowerCase();
  if (users.find(role, uname)) return res.status(409).json({ error: 'That username is taken. Try another one.' });
  const id = randomUUID();
  users.create({ id, role, username: uname, passwordHash: hashPassword(password), profile });
  return res.status(201).json({ user: { id, role, username: uname, ...profile }, token: signToken({ sub: id, role }) });
});

app.post('/api/auth/login', authLimiter, (req, res) => {
  const { role, username, password } = req.body || {};
  const row = ROLES.has(role) && typeof username === 'string' ? users.find(role, username.toLowerCase()) : null;
  if (!row || typeof password !== 'string' || !verifyPassword(password, row.password_hash)) return res.status(401).json({ error: 'That username and password do not match.' });
  return res.json({ user: publicUser(row), token: signToken({ sub: row.id, role: row.role }), progress: role === 'student' ? progress.get(row.id) : null });
});

app.get('/api/auth/me', requireAuth(), (req, res) => {
  const row = users.byId(req.user.sub);
  if (!row) return res.status(404).json({ error: 'Account not found.' });
  return res.json({ user: publicUser(row) });
});

// ---------- progress ----------
app.get('/api/progress', requireAuth({ role: 'student' }), (req, res) => res.json({ data: progress.get(req.user.sub) }));
app.put('/api/progress', requireAuth({ role: 'student' }), (req, res) => {
  const data = req.body?.data;
  if (!data || typeof data !== 'object' || Array.isArray(data)) return res.status(400).json({ error: 'Invalid progress data.' });
  const size = JSON.stringify(data).length;
  if (size > 250_000) return res.status(413).json({ error: 'Progress data is too large.' });
  progress.put(req.user.sub, data);
  return res.json({ ok: true });
});

// ---------- assignments ----------
const TYPES = new Set(['Lesson', 'Questions', 'Challenge', 'Activity', 'Diagnostic test']);
const DIFFS = new Set(['Easy', 'Medium', 'Hard', 'Advanced']);
app.get('/api/assignments', requireAuth(), (req, res) => {
  if (req.user.role === 'teacher') return res.json({ assignments: assignments.forTeacher(req.user.sub) });
  const cls = clean(req.query.class, 10);
  return res.json({ assignments: cls ? assignments.forClass(cls) : [] });
});
app.post('/api/assignments', requireAuth({ role: 'teacher' }), (req, res) => {
  const b = req.body || {};
  const title = clean(b.title, 80);
  if (title.length < 3 || !TYPES.has(b.type) || !DIFFS.has(b.difficulty)) return res.status(400).json({ error: 'Check the title, type and difficulty.' });
  const classes = (Array.isArray(b.classes) ? b.classes : []).map((c) => clean(c, 10)).filter(Boolean).slice(0, 10);
  if (!classes.length) return res.status(400).json({ error: 'Assign to at least one class.' });
  const items = (Array.isArray(b.items) ? b.items : []).slice(0, 30).map((q) => ({ prompt: clean(q.prompt, 200), answer: clean(q.answer, 40), wrong: clean(q.wrong, 40), why: clean(q.why, 240) })).filter((q) => q.prompt && q.answer);
  const id = randomUUID();
  const data = { type: b.type, title, subject: clean(b.subject, 30), concept: clean(b.concept, 20), difficulty: b.difficulty, due: clean(b.due, 10), notes: clean(b.notes, 2000), items, questions: items.length };
  assignments.create({ id, teacherId: req.user.sub, data, classes });
  return res.status(201).json({ assignment: { id, ...data, classes } });
});
app.delete('/api/assignments/:id', requireAuth({ role: 'teacher' }), (req, res) => { assignments.remove(clean(req.params.id, 60), req.user.sub); res.json({ ok: true }); });

// ---------- AI ----------
app.post('/api/tutor', aiLimiter, needAI, requireAuth({ optional: true }), asyncRoute(async (req, res) => {
  const raw = Array.isArray(req.body?.messages) ? req.body.messages.slice(-12) : [];
  const messages = raw.filter((m) => m && (m.role === 'user' || m.role === 'assistant')).map((m) => ({ role: m.role, content: clean(m.content, 2000) })).filter((m) => m.content);
  if (!messages.length || messages[messages.length - 1].role !== 'user') return res.status(400).json({ error: 'Send a message.' });
  const s = req.body.student || null;
  const student = s && typeof s === 'object' ? {
    name: clean(s.name, 40), grade: clean(s.grade, 20), preference: clean(s.preference, 20),
    weakest: (Array.isArray(s.weakest) ? s.weakest : []).slice(0, 3).map((w) => ({ concept: clean(w.concept, 40), mastery: Number(w.mastery) || 0 })),
    recentMistakes: (Array.isArray(s.recentMistakes) ? s.recentMistakes : []).slice(0, 3).map((x) => ({ question: clean(x.question, 60), answer: clean(x.answer, 20), pattern: clean(x.pattern, 60) })),
  } : null;
  const context = { concept: clean(req.body.context?.concept, 40) || null, question: clean(req.body.context?.question, 80) || null };
  return res.json({ reply: await tutorReply({ messages, student, context, lang: langOf(req.body.lang) }) });
}));

app.post('/api/explain', aiLimiter, needAI, requireAuth({ optional: true }), asyncRoute(async (req, res) => {
  const b = req.body || {};
  const explanation = await explainMistake({ prompt: clean(b.prompt, 80), question: clean(b.question, 80), studentAnswer: clean(b.studentAnswer, 30), correctAnswer: clean(b.correctAnswer, 30), pattern: clean(b.pattern, 60), lang: langOf(b.lang) });
  return res.json({ explanation });
}));

app.post('/api/diagnose', aiLimiter, needAI, requireAuth({ optional: true }), asyncRoute(async (req, res) => {
  const d = req.body?.diagnosis || {};
  const diagnosis = { headline: clean(d.headline, 200), text: clean(d.text, 500), strengths: (d.strengths || []).slice(0, 6).map((x) => clean(x, 40)), patterns: (d.patterns || []).slice(0, 6).map((p) => ({ label: clean(p.label, 60), count: Number(p.count) || 0 })) };
  return res.json({ recommendation: await recommend({ diagnosis, preference: clean(req.body?.preference, 20), lang: langOf(req.body?.lang) }) });
}));

// DigiScan: validated image upload → AI transcription → deterministic step checker
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => cb(null, ['image/png', 'image/jpeg', 'image/webp'].includes(file.mimetype)),
});
function isImage(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'image/webp';
  return null;
}
app.post('/api/scan', aiLimiter, needAI, requireAuth({ optional: true }), upload.single('image'), asyncRoute(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Upload a PNG, JPG or WEBP image up to 5 MB.' });
  const mime = isImage(req.file.buffer);
  if (!mime) return res.status(400).json({ error: 'That file is not a valid image.' });
  const { steps, note } = await transcribeWork(req.file.buffer, mime); // the image is processed in memory and never stored
  return res.json({ steps, note, analysis: steps.length ? analyzeSteps(steps) : null });
}));

// Voice: speech-to-text and text-to-speech for the tutor. Audio stays in memory and is never stored.
const voiceLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Digi Helper needs a short break. Try again in a minute.' } });
const AUDIO_TYPES = ['audio/webm', 'audio/ogg', 'audio/mp4', 'audio/mpeg', 'audio/wav', 'audio/x-wav'];
const audioUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 1, fields: 4 },
  fileFilter: (req, file, cb) => cb(null, AUDIO_TYPES.includes(String(file.mimetype).split(';')[0])),
});
function isAudio(buf) {
  if (!buf || buf.length < 12) return false;
  const h = buf.slice(0, 4);
  return (h[0] === 0x1a && h[1] === 0x45 && h[2] === 0xdf && h[3] === 0xa3) // webm / matroska
    || h.toString() === 'OggS' || h.toString() === 'RIFF' || h.toString() === 'ID3'
    || (h[0] === 0xff && (h[1] & 0xe0) === 0xe0) // mp3 frame
    || buf.slice(4, 8).toString() === 'ftyp'; // mp4 / m4a
}
app.post('/api/voice/transcribe', voiceLimiter, needAI, requireAuth({ optional: true }), audioUpload.single('audio'), asyncRoute(async (req, res) => {
  if (!req.file || !isAudio(req.file.buffer)) return res.status(400).json({ error: 'Send a short audio recording (up to 8 MB).' });
  const text = await transcribeSpeech(req.file.buffer, String(req.file.mimetype).split(';')[0], langOf(req.body?.lang));
  return res.json({ text: clean(text, 1000) });
}));
app.post('/api/voice/speak', voiceLimiter, needAI, requireAuth({ optional: true }), asyncRoute(async (req, res) => {
  const text = clean(req.body?.text, 1900);
  if (!text) return res.status(400).json({ error: 'Nothing to read aloud.' });
  const audio = await speakText(text, langOf(req.body?.lang));
  res.set({ 'Content-Type': 'audio/mpeg', 'Cache-Control': 'no-store' });
  return res.send(audio);
}));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// ---------- static client ----------
const dist = resolve(here, '../../client/dist');
if (existsSync(dist)) {
  app.use(express.static(dist, { maxAge: '1h', index: false }));
  app.get(/^(?!\/api\/).*/, (req, res) => res.sendFile(resolve(dist, 'index.html')));
}

// ---------- errors ----------
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? (req.path.startsWith('/api/voice') ? 'That recording is too long.' : 'That photo is larger than 5 MB.') : 'Upload failed.' });
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Request too large.' });
  console.error('[digi-helper]', err?.status || '', err?.message);
  const status = err?.status && err.status < 600 ? (err.status === 401 ? 502 : err.status) : 500;
  return res.status(status).json({ error: status === 429 ? 'The AI service is busy. Try again shortly.' : 'Something went wrong on the server. Try again.' });
});

app.listen(PORT, () => console.log(`Digi Helper server on http://localhost:${PORT} · AI ${aiEnabled ? 'enabled' : 'disabled (set OPENAI_API_KEY)'}`));
