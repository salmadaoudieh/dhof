// SQLite storage using Node's built-in driver (Node 22.5+). Swap for a cloud database by
// re-implementing these few functions.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const file = resolve(process.env.DATABASE_FILE || './data/digi-helper.sqlite');
mkdirSync(dirname(file), { recursive: true });
const db = new DatabaseSync(file);

db.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    role TEXT NOT NULL CHECK (role IN ('student','teacher')),
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    profile TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE (role, username)
  );
  CREATE TABLE IF NOT EXISTS progress (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS assignments (
    id TEXT PRIMARY KEY,
    teacher_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    classes TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
`);

export const users = {
  create: (u) => db.prepare('INSERT INTO users (id, role, username, password_hash, profile, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(u.id, u.role, u.username, u.passwordHash, JSON.stringify(u.profile), Date.now()),
  find: (role, username) => db.prepare('SELECT * FROM users WHERE role = ? AND username = ?').get(role, username),
  byId: (id) => db.prepare('SELECT * FROM users WHERE id = ?').get(id),
};

export const progress = {
  get: (userId) => { const r = db.prepare('SELECT data FROM progress WHERE user_id = ?').get(userId); return r ? JSON.parse(r.data) : null; },
  put: (userId, data) => db.prepare('INSERT INTO progress (user_id, data, updated_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at')
    .run(userId, JSON.stringify(data), Date.now()),
};

export const assignments = {
  create: (a) => db.prepare('INSERT INTO assignments (id, teacher_id, data, classes, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(a.id, a.teacherId, JSON.stringify(a.data), a.classes.join(','), Date.now()),
  forTeacher: (tid) => db.prepare('SELECT * FROM assignments WHERE teacher_id = ? ORDER BY created_at DESC').all(tid).map(row),
  forClass: (cls) => db.prepare("SELECT * FROM assignments WHERE ',' || classes || ',' LIKE ? ORDER BY created_at DESC").all(`%,${cls},%`).map(row),
  remove: (id, tid) => db.prepare('DELETE FROM assignments WHERE id = ? AND teacher_id = ?').run(id, tid),
};
function row(r) { return { id: r.id, ...JSON.parse(r.data), classes: r.classes.split(','), createdAt: r.created_at }; }
