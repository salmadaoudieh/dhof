import { randomBytes, scryptSync, timingSafeEqual, createHmac } from 'node:crypto';

const SECRET = process.env.AUTH_SECRET || (() => {
  console.warn('[digi-helper] AUTH_SECRET is not set — using a random secret. Sessions will reset on restart.');
  return randomBytes(32).toString('hex');
})();
const TTL = 1000 * 60 * 60 * 24 * 7; // 7 days

export function hashPassword(pw) {
  const salt = randomBytes(16);
  const key = scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('hex')}$${key.toString('hex')}`;
}
export function verifyPassword(pw, stored) {
  const [, saltHex, keyHex] = String(stored).split('$');
  if (!saltHex || !keyHex) return false;
  const key = scryptSync(pw, Buffer.from(saltHex, 'hex'), 64, { N: 16384, r: 8, p: 1 });
  const want = Buffer.from(keyHex, 'hex');
  return want.length === key.length && timingSafeEqual(want, key);
}

const b64 = (s) => Buffer.from(s).toString('base64url');
export function signToken(payload) {
  const body = b64(JSON.stringify({ ...payload, exp: Date.now() + TTL }));
  const sig = createHmac('sha256', SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
export function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const want = createHmac('sha256', SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig || ''); const b = Buffer.from(want);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch { return null; }
}

/** Express middleware. `optional` lets anonymous demo users through with req.user = null. */
export function requireAuth({ role, optional = false } = {}) {
  return (req, res, next) => {
    const h = req.get('authorization') || '';
    const user = verifyToken(h.startsWith('Bearer ') ? h.slice(7) : null);
    if (!user && !optional) return res.status(401).json({ error: 'Please log in again.' });
    if (user && role && user.role !== role) return res.status(403).json({ error: 'This area is for ' + role + 's.' });
    req.user = user; return next();
  };
}
