// Shared linear-equation toolkit used by DigiScan (client + server) and the tutor.
// Parses equations in one variable (x) into the normal form a·x + b = 0,
// solves them, and finds the first step in a worked solution that breaks the balance.

const EPS = 1e-9;

function tokenize(src) {
  const s = String(src)
    .replace(/[−–—]/g, '-')
    .replace(/[×·]/g, '*')
    .replace(/÷/g, '/')
    .replace(/\s+/g, '')
    .toLowerCase();
  const tokens = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const n = Number(s.slice(i, j));
      if (Number.isNaN(n)) return null;
      tokens.push({ t: 'num', v: n, raw: s.slice(i, j) });
      i = j;
    } else if (c === 'x') { tokens.push({ t: 'x' }); i++; }
    else if ('+-*/()='.includes(c)) { tokens.push({ t: c }); i++; }
    else return null;
  }
  return tokens;
}

// Linear form {a, b} meaning a·x + b
function parseSide(tokens) {
  let pos = 0;
  const peek = () => tokens[pos];
  const eat = (t) => (peek() && peek().t === t ? tokens[pos++] : null);

  function expr() {
    let left = term();
    while (left && peek() && (peek().t === '+' || peek().t === '-')) {
      const op = tokens[pos++].t;
      const right = term();
      if (!right) return null;
      left = op === '+' ? { a: left.a + right.a, b: left.b + right.b } : { a: left.a - right.a, b: left.b - right.b };
    }
    return left;
  }
  function term() {
    let left = factor();
    while (left && peek()) {
      const p = peek();
      if (p.t === '*' || p.t === '/') {
        pos++;
        const right = factor();
        if (!right) return null;
        left = p.t === '*' ? mul(left, right) : div(left, right);
      } else if (p.t === 'x' || p.t === '(' || p.t === 'num') {
        const right = factor(); // implicit multiplication: 3x, 2(x+1)
        if (!right) return null;
        left = mul(left, right);
      } else break;
      if (!left) return null;
    }
    return left;
  }
  function factor() {
    const p = peek();
    if (!p) return null;
    if (p.t === '-') { pos++; const f = factor(); return f && { a: -f.a, b: -f.b }; }
    if (p.t === '+') { pos++; return factor(); }
    if (p.t === 'num') { pos++; return { a: 0, b: p.v }; }
    if (p.t === 'x') { pos++; return { a: 1, b: 0 }; }
    if (p.t === '(') { pos++; const e = expr(); if (!eat(')')) return null; return e; }
    return null;
  }
  function mul(l, r) {
    if (Math.abs(l.a) > EPS && Math.abs(r.a) > EPS) return null; // x² is not linear
    return { a: l.a * r.b + r.a * l.b, b: l.b * r.b };
  }
  function div(l, r) {
    if (Math.abs(r.a) > EPS || Math.abs(r.b) < EPS) return null;
    return { a: l.a / r.b, b: l.b / r.b };
  }
  const result = expr();
  if (!result || pos !== tokens.length) return null;
  return result;
}

export function parseEquation(line) {
  const tokens = tokenize(line);
  if (!tokens) return null;
  const eqIdx = tokens.findIndex((t) => t.t === '=');
  if (eqIdx < 0 || tokens.filter((t) => t.t === '=').length !== 1) return null;
  const L = parseSide(tokens.slice(0, eqIdx));
  const R = parseSide(tokens.slice(eqIdx + 1));
  if (!L || !R) return null;
  const a = L.a - R.a;
  const b = L.b - R.b;
  // signed constants that appear in the written line, e.g. "-6" → -6
  const constants = [];
  tokens.forEach((t, i) => {
    if (t.t !== 'num') return;
    const prev = tokens[i - 1];
    const nextIsX = tokens[i + 1] && tokens[i + 1].t === 'x';
    if (nextIsX) return;
    const sign = prev && prev.t === '-' ? -1 : 1;
    constants.push(sign * t.v);
  });
  return { a, b, constants, hasX: tokens.some((t) => t.t === 'x') };
}

export function solveForm(f) {
  if (!f) return { kind: 'invalid' };
  if (Math.abs(f.a) < EPS) return Math.abs(f.b) < EPS ? { kind: 'all' } : { kind: 'none' };
  return { kind: 'one', x: -f.b / f.a };
}

export function fmt(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return '?';
  const r = Math.round(n * 1000) / 1000;
  return (r < 0 ? '−' : '') + Math.abs(r);
}

function sameSolution(s1, s2) {
  if (s1.kind !== s2.kind) return false;
  if (s1.kind !== 'one') return true;
  return Math.abs(s1.x - s2.x) < 1e-6;
}

// Default translator: English with {placeholders} filled. The client passes its own t().
const defaultTr = (s, vars) => s.replace(/\{(\w+)\}/g, (m, k) => (vars && vars[k] !== undefined ? vars[k] : m));

/**
 * Analyze a worked solution, one equation per line.
 * Returns { steps, errorIndex, finding, correctAnswer, studentAnswer }.
 * `tr(english, vars)` translates the messages; `finding.concept` stays English (an id),
 * `finding.conceptLabel` is the translated concept name.
 */
export function analyzeSteps(lines, tr = defaultTr) {
  const clean = lines.map((l) => String(l).trim()).filter(Boolean).slice(0, 20);
  const steps = clean.map((line) => {
    const form = parseEquation(line);
    return { line, form, solution: solveForm(form), parsed: !!form };
  });
  const first = steps.find((s) => s.parsed);
  if (!first) {
    return { steps, errorIndex: -1, finding: { type: 'unreadable', title: tr('We could not read these steps as equations.'), detail: tr('Write one equation per line, for example {example}.', { example: '3x + 5 = 20' }) } };
  }
  const correct = first.solution;
  let prevIdx = steps.indexOf(first);
  let errorIndex = -1;
  let finding = null;

  for (let i = prevIdx + 1; i < steps.length; i++) {
    const cur = steps[i];
    if (!cur.parsed) continue;
    const prev = steps[prevIdx];
    if (!sameSolution(prev.solution, cur.solution)) {
      errorIndex = i;
      finding = explainBreak(prev, cur, i, tr);
      break;
    }
    prevIdx = i;
  }

  const last = [...steps].reverse().find((s) => s.parsed);
  const result = {
    steps,
    errorIndex,
    finding,
    correctAnswer: correct.kind === 'one' ? correct.x : null,
    studentAnswer: last && last.solution.kind === 'one' ? last.solution.x : null,
  };
  if (errorIndex < 0) {
    result.finding = {
      type: 'correct',
      title: tr('Every step keeps the equation balanced.'),
      detail: correct.kind === 'one' ? tr('The solution is x = {x}.', { x: fmt(correct.x) }) : tr('Nice work.'),
      concept: 'Linear Equations',
      conceptLabel: tr('Linear Equations'),
    };
  }
  return result;
}

function explainBreak(prev, cur, i, tr = defaultTr) {
  const stepNo = i + 1;
  const base = { step: stepNo, before: prev.solution, after: cur.solution };
  const title = tr('Step {n} needs attention.', { n: stepNo });
  const concept = (c) => ({ concept: c, conceptLabel: tr(c) });
  if (Math.abs(cur.form.a) < EPS && prev.form.a !== 0) {
    return { ...base, type: 'lost-x', title, detail: tr('The x terms disappeared in this step. Check how you combined the x terms.'), ...concept('Like Terms') };
  }
  // Scale the current form so its x coefficient matches the previous one, then compare constants
  const scale = prev.form.a / cur.form.a;
  const diff = cur.form.b * scale - prev.form.b;
  const candidates = prev.form.constants.filter((k) => Math.abs(Math.abs(diff) - 2 * Math.abs(k)) < 1e-6 && Math.abs(k) > EPS);
  if (candidates.length) {
    const k = candidates[0];
    const from = k < 0 ? `−${Math.abs(k)}` : `+${Math.abs(k)}`;
    const to = k < 0 ? `+${Math.abs(k)}` : `−${Math.abs(k)}`;
    const stayed = cur.form.constants.some((c) => Math.abs(Math.abs(c) - Math.abs(k)) < 1e-6);
    if (stayed) {
      return { ...base, type: 'sign', title, detail: tr('You changed {from} to {to} in this step.', { from, to }), why: tr('A term only changes sign when you move it to the other side of the equals sign. Here it stayed on the same side, so it should still be {from}.', { from }), ...concept('Negative Numbers') };
    }
    return { ...base, type: 'sign', title, detail: tr('When {from} moved to the other side, it kept its sign. It should become {to}.', { from, to }), why: tr('Moving a term across the equals sign is the same as doing the opposite operation to both sides, so {from} turns into {to}.', { from, to }), ...concept('Negative Numbers') };
  }
  if (prev.solution.kind === 'one' && cur.solution.kind === 'one' && Math.abs(prev.solution.x + cur.solution.x) < 1e-6) {
    return { ...base, type: 'sign', title, detail: tr('Your answer flipped from x = {a} to x = {b}. A sign changed somewhere in this step.', { a: fmt(prev.solution.x), b: fmt(cur.solution.x) }), why: tr('Check every minus sign when you move or divide terms.'), ...concept('Negative Numbers') };
  }
  if (Math.abs(diff) < 1e-6) {
    return { ...base, type: 'balance', title, detail: tr('The x terms changed but the numbers did not. You may have divided or multiplied only one side.'), why: tr('Whatever you do to one side, do to the other side too.'), ...concept('Linear Equations') };
  }
  return { ...base, type: 'arithmetic', title, detail: tr('This step changes the solution from x = {a} to x = {b}. Check the arithmetic when moving or combining numbers.', { a: fmt(prev.solution.x), b: fmt(cur.solution.x) }), why: tr('Redo the calculation for this line on its own, then compare.'), ...concept('Linear Equations') };
}
