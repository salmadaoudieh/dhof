import { useId } from 'react';
import { useVoice, speak, stopSpeaking, listen, stopListening } from '../lib/voice.js';
import { play } from '../lib/sound.js';
import { t } from '../lib/i18n.js';

/** 🔊 Read some text aloud; press again to stop. Hidden when no voice is available here. */
export function SpeakButton({ text, id, className = '', label, small = true }) {
  const auto = useId(); const key = id || auto;
  const v = useVoice();
  if (!v.canSpeak || !text) return null;
  const on = v.speakingId === key;
  return (
    <button type="button" className={`btn btn-ghost ${small ? 'btn-sm px-2' : ''} ${on ? 'speaking' : ''} ${className}`}
      onClick={() => (on ? stopSpeaking() : speak(typeof text === 'function' ? text() : text, { id: key }))}
      aria-label={on ? t('Stop reading') : (label || t('Read aloud'))} aria-pressed={on} title={on ? t('Stop reading') : (label || t('Read aloud'))}>
      <span aria-hidden="true">{on ? '⏹' : '🔊'}</span>{!small && <span>{on ? t('Stop') : (label || t('Read aloud'))}</span>}
    </button>
  );
}

function MicIcon() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></svg>;
}

/** 🎙 Dictate into a field. onFinal receives settled words; onEnd fires when listening stops. */
export function MicButton({ onFinal, onPartial, onEnd, className = '' }) {
  const v = useVoice();
  if (!v.canListen) return null;
  const on = v.listening;
  function click() {
    if (on) { play('micOff'); stopListening(); return; }
    play('micOn');
    listen({ onFinal, onPartial, onEnd }); // synchronous from the click, as dictation requires
  }
  return (
    <button type="button" onClick={click} className={`btn ${on ? 'btn-primary mic-live' : ''} px-3 ${className}`}
      aria-label={on ? t('Stop listening') : t('Speak your message')} aria-pressed={on} title={on ? t('Stop listening') : t('Speak your message')}>
      <MicIcon />
    </button>
  );
}

/** Big voice-chat orb: tap to talk, tap again to send; shows listening / thinking / speaking. */
export function VoiceOrb({ phase, partial, onTap, onStop }) {
  const label = {
    idle: t('Tap to talk'), listening: t('Listening… tap to send'), thinking: t('Thinking…'), speaking: t('Speaking… tap to interrupt'),
  }[phase];
  return (
    <div className="grid place-items-center gap-3 py-4 text-center">
      <button type="button" onClick={phase === 'speaking' ? onStop : onTap} disabled={phase === 'thinking'}
        className={`voice-orb voice-${phase}`} aria-label={label}>
        <span className="voice-ring" aria-hidden="true" /><span className="voice-ring r2" aria-hidden="true" />
        <span className="voice-core" aria-hidden="true">{phase === 'speaking' ? <Bars /> : phase === 'thinking' ? '…' : <MicIcon />}</span>
      </button>
      <div className="font-display font-semibold" aria-live="polite">{label}</div>
      <div className="text-sm text-muted min-h-[1.5em] max-w-[30ch]">{partial}</div>
    </div>
  );
}
function Bars() {
  return <span className="voice-bars"><i /><i /><i /><i /><i /></span>;
}
