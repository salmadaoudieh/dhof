import { useEffect, useState } from 'react';
import { confetti } from '../lib/fx.js';
import { useStore } from '../lib/store.jsx';
import { checkAnswer, similarQuestion, answerLabel, correctLabel } from '../lib/questions.js';
import { t, getLang } from '../lib/i18n.js';
import { recordAttempt } from '../lib/engine.js';
import { CONCEPT } from '../lib/data.js';
import { api } from '../lib/api.js';
import { openTutor } from './Tutor.jsx';
import { mistakeCheer } from '../lib/encourage.js';
import { QDisplay } from './ui.jsx';
import { play } from '../lib/sound.js';
import { claudeSample } from '../lib/voice.js';
import { SpeakButton } from './Voice.jsx';

const lastNumber = (s) => { const nums = String(s).replace(/[−]/g, '-').match(/-?\d+(\.\d+)?(\/\d+)?/g); return nums ? nums[nums.length - 1] : null; };
const norm = (s) => String(s ?? '').replace(/[−]/g, '-').replace(/\s+/g, '');

export function AnswerInput({ q, value, onChange, onSubmit, disabled, id = 'answer' }) {
  if (q.type === 'mc') {
    return (
      <div className="grid sm:grid-cols-2 gap-2" role="radiogroup" aria-label={t('Choose an answer')}>
        {q.options.map((o, k) => (
          <button key={o.id} type="button" role="radio" aria-checked={value === o.id} disabled={disabled} onClick={() => onChange(o.id)}
            className={`panel px-4 py-3 font-semibold text-start transition hover:border-[var(--accent)] flex gap-3 items-start ${value === o.id ? 'ring-2 ring-[var(--accent)]' : ''}`}>
            <span className="hue-chip w-7 h-7 text-xs font-mono uppercase shrink-0" style={{ '--h': ['#3b82f6', '#a855f7', '#ec4899', '#f59e0b'][k % 4] }} aria-hidden="true">{o.id}</span>
            <span className={/^[\sx<>≤≥=0-9.+\-−()]+$/.test(o.text) ? 'math font-mono' : ''}>{o.text}</span>
          </button>
        ))}
      </div>
    );
  }
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit?.(); }} className="flex gap-2">
      <label htmlFor={id} className="sr-only">{t('Your answer')}</label>
      <input id={id} className="input font-mono text-lg" inputMode="text" autoComplete="off" placeholder={q.skill === 'frac' ? t('e.g. 5/6') : t('Your answer')} value={value} onChange={(e) => onChange(e.target.value.slice(0, 20))} disabled={disabled} />
    </form>
  );
}

/** Fix it for reasoning questions: reveal the path one step at a time, then pick the answer. */
function FixItReasoning({ q }) {
  const [i, setI] = useState(0);
  const [pickId, setPick] = useState(null);
  const done = i >= q.steps.length;
  return (
    <div className="grid gap-3">
      <ol className="grid gap-2">
        {q.steps.slice(0, i).map((s, k) => (
          <li key={k} className="panel p-3 flex gap-3 anim-pop"><span className="pill pill-info shrink-0">{k + 1}</span><span>{s.text}</span></li>
        ))}
      </ol>
      {!done ? (
        <button className="btn btn-primary justify-self-start" onClick={() => setI((k) => k + 1)}>{i === 0 ? t('Show the first step') : t('Next step')} <span className="dir-arrow">→</span></button>
      ) : q.type === 'mc' ? (
        <div className="grid gap-2 anim-pop">
          <div className="font-semibold">{t('Now, which answer fits this reasoning?')}</div>
          <AnswerInput q={q} value={pickId} onChange={setPick} id={`fixr-${q.id}`} />
          {pickId && (pickId === q.answer ? <p className="text-good font-semibold">✓ {t('Exactly. Now prove it on a fresh question.')}</p> : <p className="text-bad text-sm">{t('Not quite — read the last step again.')}</p>)}
        </div>
      ) : <div className="text-good font-semibold">✓ {t('Answer: {a}. Now prove it on a fresh question.', { a: correctLabel(q) })}</div>}
    </div>
  );
}

/** Fix it: the student rebuilds the solution one step at a time. */
function FixIt({ q }) {
  if (q.textual || q.steps.every((s) => !s.expr)) return <FixItReasoning q={q} />;
  const [i, setI] = useState(0); const [val, setVal] = useState(''); const [state, setState] = useState(null);
  const step = q.steps[i];
  const done = i >= q.steps.length;
  function check() {
    const want = lastNumber(step.expr); const got = lastNumber(val) ?? norm(val);
    const ok = want !== null && got !== null && (norm(got) === norm(want) || Math.abs(Number(eval0(got)) - Number(eval0(want))) < 1e-6);
    setState(ok ? 'ok' : 'no'); play(ok ? (i + 1 >= q.steps.length ? 'fixed' : 'correct') : 'hint');
    if (ok) setTimeout(() => { setI((k) => k + 1); setVal(''); setState(null); }, 700);
  }
  return (
    <div className="grid gap-3">
      <ol className="grid gap-2">
        {q.steps.slice(0, i).map((s, k) => (
          <li key={k} className="panel p-3 flex gap-3 anim-pop"><span className="pill pill-good">✓ {k + 1}</span><div><div className="text-sm text-muted">{s.text}</div><div className="font-mono font-semibold">{s.expr}</div></div></li>
        ))}
      </ol>
      {!done ? (
        <div className={`panel p-4 grid gap-2 ${state === 'no' ? 'anim-shake' : ''}`}>
          <div className="text-sm"><span className="pill pill-info me-2">{t('Step {n}', { n: i + 1 })}</span><strong>{step.text}.</strong> {t('What do you get?')}</div>
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); check(); }}>
            <label htmlFor={`fix-${q.id}-${i}`} className="sr-only">{t('Result of step {n}', { n: i + 1 })}</label>
            <input id={`fix-${q.id}-${i}`} className="input font-mono" value={val} onChange={(e) => setVal(e.target.value.slice(0, 30))} placeholder={t('Type the result')} autoComplete="off" />
            <button className="btn btn-primary">{t('Check')}</button>
          </form>
          <div className="flex items-center justify-between text-sm min-h-6">
            <span aria-live="polite">{state === 'no' && <span className="text-bad">{t('Not yet — try again, or reveal it.')}</span>}{state === 'ok' && <span className="text-good">✓ {t('Exactly.')}</span>}</span>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setVal(step.expr); setTimeout(() => { setI((k) => k + 1); setVal(''); setState(null); }, 900); }}>{t('Reveal step')}</button>
          </div>
        </div>
      ) : <div className="text-good font-semibold">✓ {t('Solved: {a}. Now prove it on a fresh question below.', { a: correctLabel(q) })}</div>}
    </div>
  );
}
function eval0(s) { const f = String(s).match(/^(-?\d+(?:\.\d+)?)\/(\d+)$/); return f ? Number(f[1]) / Number(f[2]) : Number(s); }

function TryAgain({ q }) {
  const { updateStudent, student } = useStore();
  const [nq, setNq] = useState(() => similarQuestion(q));
  const [val, setVal] = useState(''); const [res, setRes] = useState(null);
  function submit() {
    const r = checkAnswer(nq, val); if (r.invalid) { setRes({ invalid: true }); return; }
    setRes(r);
    if (student) updateStudent((s) => recordAttempt(s, nq.skill, { ok: r.ok, mis: r.mis || r.generic, difficulty: nq.difficulty, wasRetry: true }));
    if (r.ok) { confetti({ count: 90 }); play('fixed'); } else play('gentle');
  }
  return (
    <div className="grid gap-3">
      <div><div className="text-sm text-muted">{nq.prompt}</div><QDisplay q={nq} size="md" /></div>
      <AnswerInput q={nq} value={val} onChange={setVal} onSubmit={submit} disabled={res?.ok} id={`retry-${nq.id}`} />
      <div className="flex flex-wrap gap-2 items-center">
        {!res?.ok && <button className="btn btn-primary" onClick={submit} disabled={!val}>{t('Check answer')}</button>}
        {res && <button className="btn" onClick={() => { setNq(similarQuestion(nq)); setVal(''); setRes(null); }}>{t('Another one')} <span className="dir-arrow">→</span></button>}
      </div>
      <div aria-live="polite">
        {res?.invalid && <p className="text-warn text-sm">{nq.skill === 'frac' ? t('Type a number or a fraction like 3/4.') : t('Type a number.')}</p>}
        {res?.ok && <p className="text-good font-semibold anim-pop">🎉 {t("Mistake turned into progress. That's exactly the step that tripped you up before.")}</p>}
        {res && !res.ok && !res.invalid && <p className="text-bad text-sm">{t('Not yet.')} {(res.mis || res.generic)?.found} <span className="text-muted">{nq.hint}</span></p>}
      </div>
    </div>
  );
}

export default function MistakeDetective({ q, raw, result, compact }) {
  const { srv, state } = useStore();
  const mis = result.mis || result.generic;
  const matched = !!result.mis;
  const [tab, setTab] = useState('why');
  const [ai, setAi] = useState(null);
  const [cheer] = useState(mistakeCheer);
  const correct = correctLabel(q);
  const rawText = answerLabel(q, raw);
  useEffect(() => { play('gentle'); }, []);
  const canAI = srv.ai || !!claudeSample();

  async function aiExplain() {
    setAi({ loading: true });
    try {
      const sample = !srv.ai && claudeSample();
      if (sample) {
        const lang = { en: 'English', ar: 'Arabic (Modern Standard Arabic, Western digits)', fr: 'French (use « tu »)' }[getLang()] || 'English';
        const r = await sample(`You are Digi Helper, a kind tutor for school students. Explain a single mistake in 3 short sentences: what likely happened, why it is wrong, and one tip to avoid it next time. End with a short encouraging line. Plain text, no markdown, no emoji, no greeting. Reply in ${lang}.\n\n${q.prompt} ${q.display}\nStudent answered: ${rawText}\nCorrect answer: ${correct}\nDetected pattern: ${mis?.label || 'unknown'}`, { modelTier: 'quick', onText: ({ text }) => setAi({ text, streaming: true }) });
        setAi({ text: r.text.trim() }); play('receive'); return;
      }
      const r = await api('/explain', { method: 'POST', token: state.session?.token, body: { question: q.display, prompt: q.prompt, studentAnswer: rawText, correctAnswer: String(correct), pattern: mis?.label || null, lang: getLang() } });
      setAi({ text: r.explanation });
    } catch (e) { setAi({ error: e.message }); }
  }

  return (
    <div className="glass glow-edge p-5 sm:p-6 grid gap-4 anim-pop" style={{ background: 'color-mix(in srgb, var(--surface-solid) 92%, var(--violet))' }}>
      <div className="flex items-start gap-3">
        <div className="text-3xl" aria-hidden="true">🔎</div>
        <div className="min-w-0">
          <div className="eyebrow" style={{ color: 'var(--violet)' }}>{t('Mistake Detective')}</div>
          <h3 className="font-display text-lg sm:text-xl font-semibold">{matched ? t('Mistake Detective found a pattern.') : t('Mistake Detective is on the case.')}</h3>
          <p className="mt-1 text-[1.02rem]">{mis?.found}</p>
        </div>
      </div>
      <p className="text-sm flex gap-2 items-start" style={{ color: 'var(--good)' }}><span aria-hidden="true">🌱</span><span>{cheer}</span></p>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="panel p-2.5 min-w-0"><div className="text-[0.68rem] uppercase tracking-wider text-muted font-bold">{t('Question')}</div><div className={`font-semibold text-sm sm:text-base break-words ${q.textual ? 'whitespace-pre-line line-clamp-4' : 'math font-mono'}`}>{q.display}</div></div>
        <div className="panel p-2.5 min-w-0" style={{ borderColor: 'color-mix(in srgb, var(--bad) 40%, transparent)' }}><div className="text-[0.68rem] uppercase tracking-wider text-muted font-bold">{t('Your answer')}</div><div className="font-mono font-semibold text-bad break-words">{rawText}</div></div>
        <div className="panel p-2.5 min-w-0"><div className="text-[0.68rem] uppercase tracking-wider text-muted font-bold">{t('Pattern')}</div><div className="text-xs sm:text-sm font-semibold">{t(mis?.label)}</div></div>
      </div>
      <div className="flex flex-wrap gap-2" role="tablist" aria-label={t('Mistake Detective sections')}>
        {[['why', t('Why?')], ['fix', t('Fix it')], ['retry', t('Try again')]].map(([id, l]) => (
          <button key={id} role="tab" aria-selected={tab === id} className={`chip ${tab === id ? 'on' : ''}`} onClick={() => setTab(id)}>{l}</button>
        ))}
      </div>
      <div role="tabpanel">
        {tab === 'why' && (
          <div className="grid gap-3">
            <div className="flex items-start gap-1"><p className="flex-1">{mis?.why}</p><SpeakButton id={`why-${q.id}`} text={() => `${mis?.found || ''} ${mis?.why || ''} ${cheer}`} label={t('Read the explanation aloud')} /></div>
            <p className="text-sm text-muted">{t('Concept to review:')} <strong className="text-fg">{CONCEPT[q.skill]?.name}</strong></p>
            {ai?.text && <div className="panel p-3 text-sm whitespace-pre-wrap"><div className="flex items-center justify-between"><div className="eyebrow mb-1">{t('AI explanation')}</div>{!ai.streaming && <SpeakButton id={`ai-${q.id}`} text={ai.text} />}</div>{ai.text}</div>}
            {ai?.error && <p className="text-warn text-sm">{ai.error}</p>}
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-primary btn-sm" onClick={() => setTab('fix')}>{t('Fix it step by step')} <span className="dir-arrow">→</span></button>
              {canAI && !ai?.text && <button className="btn btn-sm" onClick={aiExplain} disabled={ai?.loading}>{ai?.loading ? t('Thinking…') : `✦ ${t('Explain it another way (AI)')}`}</button>}
              {!compact && <button className="btn btn-sm" onClick={() => openTutor(t('Why is {a} wrong for {q}?', { a: rawText, q: q.display }))}>{t('Ask Digi Helper')}</button>}
            </div>
          </div>
        )}
        {tab === 'fix' && <FixIt q={q} />}
        {tab === 'retry' && <TryAgain q={q} />}
      </div>
    </div>
  );
}
